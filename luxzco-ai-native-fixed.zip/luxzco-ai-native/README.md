# LUXZCO AI — Aplikasi Android

Aplikasi Android native (Kotlin). Tidak memakai halaman website dan tidak memakai WebView.

## Isi paket
- `android/`: source aplikasi Android native.
- `backend/`: server API yang menjadi penghubung aman antara aplikasi dan model AI.
- `.github/workflows/android.yml`: alur build APK debug otomatis.

## Fitur Android
- Chat native bertema gelap dengan aksen biru LUXZCO.
- Riwayat chat tersimpan di perangkat.
- Pengaturan alamat server dari dalam aplikasi.
- Tidak menyimpan API key model AI di dalam APK.

## Status saat ini
Source aplikasi Android dan backend API sudah disiapkan. APK belum terkompilasi di lingkungan ini karena Android SDK/Gradle tidak tersedia dan akses unduh paket build tidak tersedia. Backend juga belum di-host atau dihubungkan ke akun API.

## Build APK
Folder `android` dapat dibuka dengan Android Studio. Workflow GitHub Actions juga tersedia di `.github/workflows/android.yml` untuk membuat APK debug saat proyek diunggah ke repository GitHub dan workflow dijalankan. Hasil build adalah `app-debug.apk`.

## Mengaktifkan chat AI
Backend perlu dijalankan pada layanan hosting server (hosting biasa untuk file website saja belum tentu mendukung Node.js). Atur `OPENAI_API_KEY` dan `OPENAI_MODEL` sebagai environment variables server. Setelah server aktif, buka aplikasi → ⚙ → masukkan base URL server, misalnya `https://server-kamu.example` (tanpa `/api/chat`). API key harus tetap berada di server, jangan dimasukkan ke APK.
