import http from 'node:http';

const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY;
const MODEL = process.env.OPENAI_MODEL || 'gpt-6-luna';
const WINDOW_MS = 60_000;
const MAX_REQUESTS = 12;
const hits = new Map();

function json(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(data));
}

async function readBody(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 48 * 1024) throw new Error('BODY_TOO_LARGE');
    chunks.push(chunk);
  }
  return JSON.parse(Buffer.concat(chunks).toString('utf8'));
}

function limited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) return true;
  recent.push(now);
  hits.set(ip, recent);
  return false;
}

const server = http.createServer(async (req, res) => {
  const path = new URL(req.url, 'http://localhost').pathname;
  if (req.method === 'GET' && path === '/health') return json(res, 200, { ok: true, service: 'LUXZCO AI API' });
  if (path !== '/api/chat') return json(res, 404, { error: 'Endpoint tidak ditemukan.' });
  if (req.method !== 'POST') return json(res, 405, { error: 'Metode tidak diizinkan.' });
  if (limited(req.socket.remoteAddress || 'unknown')) return json(res, 429, { error: 'Terlalu banyak permintaan. Coba lagi nanti.' });
  if (!API_KEY || API_KEY === 'isi_api_key_di_server') return json(res, 503, { error: 'Server AI belum dikonfigurasi oleh pengelola.' });

  let body;
  try { body = await readBody(req); }
  catch (e) { return json(res, e.message === 'BODY_TOO_LARGE' ? 413 : 400, { error: 'Isi permintaan tidak valid atau terlalu besar.' }); }

  if (!Array.isArray(body?.messages) || body.messages.length < 1 || body.messages.length > 20) {
    return json(res, 400, { error: 'Riwayat chat tidak valid.' });
  }
  let total = 0;
  const messages = [];
  for (const m of body.messages) {
    if (!m || !['user', 'assistant'].includes(m.role) || typeof m.content !== 'string') return json(res, 400, { error: 'Pesan tidak valid.' });
    const content = m.content.trim();
    total += content.length;
    if (!content || content.length > 6000 || total > 16000) return json(res, 400, { error: 'Batas panjang pesan terlampaui.' });
    messages.push({ role: m.role, content });
  }

  try {
    const upstream = await fetch('https://api.openai.com/v1/responses', {
      method: 'POST',
      headers: { Authorization: `Bearer ${API_KEY}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        model: MODEL,
        instructions: 'Kamu adalah LUXZCO AI, asisten yang ramah, jelas, jujur, dan membantu. Jawab dalam bahasa pengguna. Jika tidak tahu, katakan dengan jujur. Jaga keamanan dan kesesuaian usia.',
        input: messages,
        max_output_tokens: 1200,
        store: false
      }),
      signal: AbortSignal.timeout(45000)
    });
    const data = await upstream.json().catch(() => ({}));
    if (!upstream.ok) return json(res, upstream.status === 429 ? 429 : 502, { error: data?.error?.message || 'Layanan AI tidak dapat digunakan.' });
    let answer = typeof data.output_text === 'string' ? data.output_text : '';
    if (!answer && Array.isArray(data.output)) {
      answer = data.output.filter(x => x.type === 'message').flatMap(x => Array.isArray(x.content) ? x.content : []).filter(x => x.type === 'output_text').map(x => x.text || '').join('\n');
    }
    if (!answer.trim()) return json(res, 502, { error: 'AI tidak mengirim jawaban.' });
    return json(res, 200, { answer: answer.trim() });
  } catch (e) {
    return json(res, 502, { error: e.name === 'TimeoutError' ? 'AI merespons terlalu lama.' : 'Server gagal menghubungi layanan AI.' });
  }
});

server.listen(PORT, '0.0.0.0', () => console.log(`LUXZCO AI API berjalan di port ${PORT}`));
