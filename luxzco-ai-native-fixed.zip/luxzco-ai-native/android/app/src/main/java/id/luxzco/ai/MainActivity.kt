package id.luxzco.ai

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.inputmethod.EditorInfo
import android.content.Context
import android.content.SharedPreferences
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences
    private lateinit var messagesBox: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var input: EditText
    private lateinit var sendButton: TextView
    private lateinit var statusText: TextView
    private val messages = mutableListOf<Pair<String, String>>()
    private val executor = Executors.newSingleThreadExecutor()
    private var waiting = false

    private val bg = Color.rgb(9, 11, 16)
    private val panel = Color.rgb(18, 23, 34)
    private val blue = Color.rgb(57, 123, 255)
    private val white = Color.rgb(245, 247, 252)
    private val muted = Color.rgb(154, 166, 186)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("luxzco_ai", Context.MODE_PRIVATE)
        loadMessages()
        buildScreen()
        renderMessages()
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(12), dp(16), dp(10))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(14))
        }
        val logo = TextView(this).apply {
            text = "L"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            background = rounded(blue, 14)
        }
        header.addView(logo, LinearLayout.LayoutParams(dp(46), dp(46)))
        val brandWrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(11), 0, 0, 0)
        }
        brandWrap.addView(label("LUXZCO AI", 19f, white, true))
        brandWrap.addView(label("FAST • TRUSTED • RELIABLE", 9f, muted, true))
        header.addView(brandWrap, LinearLayout.LayoutParams(0, -2, 1f))
        val settings = TextView(this).apply {
            text = "⚙"
            textSize = 23f
            gravity = Gravity.CENTER
            setTextColor(white)
            background = rounded(panel, 14)
            setOnClickListener { showSettings() }
        }
        header.addView(settings, LinearLayout.LayoutParams(dp(44), dp(44)))
        root.addView(header)

        statusText = label("●  SIAP DIGUNAKAN", 10f, muted, true).apply {
            setPadding(dp(2), 0, 0, dp(9))
        }
        root.addView(statusText)

        scroll = ScrollView(this).apply {
            isFillViewport = true
            overScrollMode = ScrollView.OVER_SCROLL_NEVER
        }
        messagesBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, dp(8), 0, dp(14))
        }
        scroll.addView(messagesBox)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val composer = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.BOTTOM
            background = rounded(panel, 18)
            setPadding(dp(9), dp(7), dp(7), dp(7))
        }
        input = EditText(this).apply {
            hint = "Tanyakan sesuatu..."
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 15f
            maxLines = 4
            minLines = 1
            setPadding(dp(10), dp(7), dp(8), dp(7))
            background = null
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false
            }
        }
        composer.addView(input, LinearLayout.LayoutParams(0, -2, 1f))
        sendButton = TextView(this).apply {
            text = "➤"
            textSize = 21f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = rounded(blue, 14)
            setOnClickListener { sendMessage() }
        }
        composer.addView(sendButton, LinearLayout.LayoutParams(dp(46), dp(46)))
        root.addView(composer)
        val footer = label("LUXZCO AI  •  Asisten digital", 9f, muted, false).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(9), 0, 0)
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun renderMessages() {
        messagesBox.removeAllViews()
        if (messages.isEmpty()) {
            val welcome = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(14), dp(45), dp(14), dp(35))
            }
            val icon = TextView(this).apply {
                text = "✦"
                textSize = 34f
                setTextColor(blue)
                gravity = Gravity.CENTER
            }
            welcome.addView(icon)
            welcome.addView(label("Halo, selamat datang!", 21f, white, true).apply { gravity = Gravity.CENTER })
            welcome.addView(label("Saya LUXZCO AI. Ada yang bisa saya bantu hari ini?", 13f, muted, false).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, 0)
            })
            messagesBox.addView(welcome)
        } else {
            messages.forEach { (role, content) -> addBubble(role, content) }
        }
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun addBubble(role: String, content: String) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = if (role == "user") Gravity.END else Gravity.START
            setPadding(0, dp(5), 0, dp(5))
        }
        val bubble = TextView(this).apply {
            text = content
            textSize = 15f
            setTextColor(white)
            setPadding(dp(14), dp(11), dp(14), dp(11))
            background = rounded(if (role == "user") Color.rgb(35, 72, 145) else panel, 17)
            maxWidth = (resources.displayMetrics.widthPixels * 0.82f).toInt()
            setLineSpacing(dp(2).toFloat(), 1f)
        }
        row.addView(bubble)
        messagesBox.addView(row, LinearLayout.LayoutParams(-1, -2))
    }

    private fun sendMessage() {
        if (waiting) return
        val text = input.text.toString().trim()
        if (text.isEmpty()) return
        input.setText("")
        messages.add("user" to text)
        if (messages.size > 20) messages.removeAt(0)
        saveMessages()
        renderMessages()

        val baseUrl = prefs.getString("api_base_url", "")?.trim().orEmpty().trimEnd('/')
        if (baseUrl.isBlank()) {
            addAssistantMessage("Aplikasi LUXZCO AI sudah siap. Server AI belum dihubungkan. Buka ⚙ Pengaturan dan masukkan alamat server API untuk mengaktifkan chat AI.")
            return
        }
        waiting = true
        sendButton.text = "…"
        statusText.text = "●  MENGHUBUNGKAN KE AI"
        val snapshot = messages.toList()
        executor.execute {
            try {
                val url = URL("$baseUrl/api/chat")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 50000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val body = JSONObject().put("messages", JSONArray().apply {
                    snapshot.forEach { (role, content) ->
                        put(JSONObject().put("role", role).put("content", content))
                    }
                }).toString()
                OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { it.write(body) }
                val stream = if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream
                val responseText = stream.bufferedReader().use { it.readText() }
                val response = JSONObject(responseText)
                if (connection.responseCode !in 200..299) throw Exception(response.optString("error", "Server AI mengalami kendala."))
                val answer = response.optString("answer", "AI belum memberikan jawaban.")
                runOnUiThread { waiting = false; sendButton.text = "➤"; statusText.text = "●  TERHUBUNG"; addAssistantMessage(answer) }
                connection.disconnect()
            } catch (error: Exception) {
                val message = error.message?.takeIf { it.isNotBlank() } ?: "Tidak dapat terhubung ke server AI."
                runOnUiThread { waiting = false; sendButton.text = "➤"; statusText.text = "●  SERVER BELUM TERHUBUNG"; addAssistantMessage("Koneksi gagal: $message") }
            }
        }
    }

    private fun addAssistantMessage(text: String) {
        messages.add("assistant" to text)
        if (messages.size > 20) messages.removeAt(0)
        saveMessages()
        renderMessages()
    }

    private fun showSettings() {
        val field = EditText(this).apply {
            setText(prefs.getString("api_base_url", ""))
            hint = "https://alamat-server-kamu"
            setTextColor(white)
            setHintTextColor(muted)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_URI
        }
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(8), dp(22), 0)
            addView(label("Masukkan alamat server backend LUXZCO AI. Contoh: https://server-kamu.onrender.com", 13f, muted, false))
            addView(field, LinearLayout.LayoutParams(-1, -2))
        }
        AlertDialog.Builder(this)
            .setTitle("Pengaturan LUXZCO AI")
            .setView(wrap)
            .setPositiveButton("Simpan") { _, _ ->
                prefs.edit().putString("api_base_url", field.text.toString().trim().trimEnd('/')).apply()
                statusText.text = if (field.text.isNullOrBlank()) "●  SERVER BELUM DIATUR" else "●  ALAMAT SERVER TERSIMPAN"
                Toast.makeText(this, "Pengaturan disimpan.", Toast.LENGTH_SHORT).show()
            }
            .setNeutralButton("Hapus chat") { _, _ ->
                messages.clear(); saveMessages(); renderMessages()
            }
            .setNegativeButton("Tutup", null)
            .show()
    }

    private fun loadMessages() {
        try {
            val array = JSONArray(prefs.getString("messages", "[]"))
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                messages.add(item.getString("role") to item.getString("content"))
            }
        } catch (_: Exception) { messages.clear() }
    }

    private fun saveMessages() {
        val array = JSONArray()
        messages.forEach { (role, content) -> array.put(JSONObject().put("role", role).put("content", content)) }
        prefs.edit().putString("messages", array.toString()).apply()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        executor.shutdownNow()
        super.onDestroy()
    }
}
